let clientData = "xx";
let dataBool = false;
let turnActive = false;
let turn = 0;

// Use nodejs 'Net' module
const net = require('node:net');
const fs = require('node:fs');
const { validateHeaderName } = require('node:http');

//array to contain the socket obejct of each connection
//INDEXES ALSO AVAILABLE AS j1 TO j4
const clients = [];

// Creation of the server
const server = net.createServer(socket => {

    
    
    //Print data received from client
    socket.on('data', data => {
        dataBool = true;
        console.log(' client(' + socket.clientIp + '): ' + data.toString().trim());
        /// faire un IF que si un jour joue et c pas son tour il met pas le data dans le variable  clientData
        clientData = data.toString().trim();
        game();
        //send back "recu" for test purposes ***(uncomment)***
        //socket.write('message: ' + data.toString().trim() + 'recu');
        
    })

    //Show that a client has disconnected(+ his ip)
    socket.on('end', () => {
        console.log('CLIENT DISCONNECTED ('+ socket.clientIp + ')');
    })

    //error logging
    socket.on('error', () => {
        console.log('ERROR');
    })
})

server.on('connection', socket => {

    //on connection, store each socket in 'clients' array
    clients.push(socket);

    // Store the client's IP address within the socket object
    socket.clientIp = socket.remoteAddress;

    //Send hello back to client on socket
    //socket.write('\nWelcome to TCP Server!\n');

    //Show that a client has connected(+ his ip)
    console.log('CLIENT CONNECTED (' + socket.clientIp + ')');

    //update();

    if(clients.length == 4){
        console.log("1 connections");
        initGame();
        console.log(livestack);
    };
});


//bind server to all available IP addresses on the server's network interfaces
// and listen on port 1647
const HOST = '0.0.0.0';
const PORT = 1647;
server.listen(PORT, HOST, () => {
    console.log(`${HOST} : ${PORT}`);
})


// Function to send a message to a specific client
//Use array index of the client you want to talk to in 'clients' array (use j1-4 variables ex: sendToClient(j1, 'alloTest'))
function sendToClient(clientSocket, message) {
    clientSocket.write(message);
    for(let d = 0; d < 1000; d+=0.0001){};
}



//mettre dans connection event pour dire a tt monde quand nouvelle connection

// for(let k = 0 ; k < clients.length ; k++){
//     clients[k].write('CLIENT CONNECTED (' + socket.clientIp + ')');
//     clients[k].write('\n');
// }



const readline = require('node:readline').createInterface({
    input: process.stdin,
    output: process.stdout,
  });
  
  let stack = [
    '1v', '2v', '3v', '4v', '5v', '6v', '7v', '8v', '9v', 
    '1b', '2b', '3b', '4b', '5b', '6b', '7b', '8b', '9b', 
    '1j', '2j', '3j', '4j', '5j', '6j', '7j', '8j', '9j', 
    '1r', '2r', '3r', '4r', '5r', '6r', '7r', '8r', '9r'
  ];
  
  let j1 = [], j2 = [], j3 = [], j4 = [];
  
  let playerHands = [j1, j2, j3, j4];
  
  let livestack = [];
  let NBCARDSSTART = 7;
  //let playedCard = '2j';//carte envoyé par le joueur
  let clockwise = true;
  
  function getRandomInt(max) {
    return Math.floor(Math.random() * max);
  }
  
  function distribute() {
    // Place one card from the stack on top of the livestack
    livestack.push(stack.splice(getRandomInt(stack.length), 1)[0]);
    console.log('livestack', livestack);
  
    for (let i = 0; i < NBCARDSSTART; i++) {
        for (let j = 0; j < 4; j++) {
            playerHands[j].push(stack.splice(getRandomInt(stack.length), 1)[0]);
        }
    }

    sendToClient(clients[0], "start");
    sendToClient(clients[1], "start");
    sendToClient(clients[2], "start");
    sendToClient(clients[3], "start");
    
    console.log("\nJ1");
     // migrate to distribute();
     for(let k = 0; k < j1.length; k++){
        console.log(j1[k].toString());
        sendToClient(clients[0], j1[k].toString());
    }
    console.log("\nJ2");
    for(let l = 0; l < j2.length; l++){
        console.log(j2[l].toString());
        sendToClient(clients[1], j2[l].toString());
    }

    console.log("\nJ3");
    for(let x = 0; x < j3.length; x++){
        console.log(j3[x].toString());
        sendToClient(clients[2], j3[x].toString());
    }

    console.log("\nJ4");
    for(let v = 0; v < j4.length; v++){
        console.log(j4[v].toString());
        sendToClient(clients[3], j4[v].toString());
    }
  }



  function checkCard(livestack, clientData) {
    clientData = clientData.toString();
    console.log("Je suis la dans la vie check card");
    if (clientData == "pass")
        {
            sendToClient(clients[turn], "oui");
            return true;
        }    

  else if (clientData !=  "pige")
   {
    
    if(clientData[0].toString() == livestack[0][0] ||
        clientData[1].toString() == livestack[0][1]
    ){
           sendToClient(clients[turn], "oui");
           
           
           remCard(clients[turn]);
           return true;
     }else{
        sendToClient(clients[turn], "non");
        return false;
     }

   } 
   else
        {
              
        draw();
        }
        }



        function draw(client) {
            sendToClient(clients[turn], stack.splice(getRandomInt(stack.length), 1)[0]);
           // sendToClient(clients[0], j1[k].toString());
            if(stack.length == 0){
                stack = [
                    '1v', '2v', '3v', '4v', '5v', '6v', '7v', '8v', '9v', 
                    '1b', '2b', '3b', '4b', '5b', '6b', '7b', '8b', '9b', 
                    '1j', '2j', '3j', '4j', '5j', '6j', '7j', '8j', '9j', 
                    '1r', '2r', '3r', '4r', '5r', '6r', '7r', '8r', '9r'
                  ];
            }
          }


    
  
  function turnChange() {
    if(turn == 4){
        turn = 0;
    }
   turn++;
  }
  
  function checkWinCondition() {
    for (let i = 0; i < 4; i++) {
        if (playerHands[i].length === 0) {
            console.log(`Player ${i + 1} wins!`);
            return true;
        }
    }
    return false;
  }
  

//players[turn].transmit(YOUR TURN)

//turn 0 a 3
  function transmitTurn(turn)
  {
    //console.log("transmitTest");
    sendToClient(clients[turn], "*");
  }

  function waitforcard()
  {
    console.log(dataBool);
    while(dataBool == false)
        {
           

            console.log("waitForCard is looping");
            console.log(clientData);
        }
  }

//   function remCard(joueur){
//     for(let i = 0; i < playerHands[turn]; i++){
//         if(clientData == joueur[i]){
//             joueur.splice(1,i);
           
//         }
//     }
//   }



  
  function initGame()
  {
    distribute();
    transmitTurn(turn);
    turnActive = true;
  }

  function game(socket) 
{

    if(!checkWinCondition())
    {
        //console.log("before if turn active");
        console.log("CheckTurnActive");
        if(turnActive == false)
        {
            transmitTurn(turn);
            turnActive = true;
        }

        //waitforcard();
       
        if(checkCard(livestack, clientData)) 
            {   console.log(turn);
   
                
                turnChange();
               
                console.log(turn);

                //function to pop card from player
                livestack.unshift(clientData);

                 console.log(livestack);
                remCard(playerHands[turn]);

                

                turnActive = false;
                transmitTurn(turn);
                turnActive = true;
            }
       

        
           

        //its your turn(turnID);
        //Wait for card()
        //bool valid = checkcard(laCarte)
        // communicatePlayer()
        //resolution()
        
    }

    else{
        console.log("IM DA WINNA")
    }
    
    //there is a winner

}



